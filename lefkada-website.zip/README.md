# Lefkada Homes – Steinvilla

Statische Exposé-Website für die Steinvilla auf Lefkada.

## Deployment auf Railway

Railway erkennt das `Dockerfile` automatisch und startet einen nginx-Server auf dem von Railway gesetzten `PORT`.

1. Repository auf GitHub anlegen und diesen Ordner hineinpushen.
2. In Railway: **New Project → Deploy from GitHub repo** → Repository auswählen.
3. Im Service unter **Settings → Networking** auf **Generate Domain** klicken (oder eigene Domain verbinden).

Jeder Push auf `main` wird automatisch neu veröffentlicht.

## Lokal testen

```bash
docker build -t lefkada .
docker run -p 8080:8080 lefkada
# http://localhost:8080
```

## Inhalt

- `index.html` – die komplette Seite (CSS und JS inline)
- `images/` – Renderings und Grundriss
- `grundriss.pdf` – Originalplan
